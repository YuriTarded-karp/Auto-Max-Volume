"""Host-side routing policy checks. Requires Python 3 and a JDK (javac/java).
Uses minimal Android API doubles; does not replace tests on a real phone.
Run: python3 tests/test_devices.py
"""
import pathlib, subprocess, tempfile, os
root = pathlib.Path(__file__).resolve().parents[1]
java_home = os.environ.get('JAVA_HOME')
javac = str(pathlib.Path(java_home) / 'bin/javac') if java_home else 'javac'
java = str(pathlib.Path(java_home) / 'bin/java') if java_home else 'java'
sources = {
'android/media/AudioAttributes.java': '''package android.media;
public class AudioAttributes { public static final int USAGE_MEDIA=1, CONTENT_TYPE_MUSIC=2;
public static class Builder { public Builder setUsage(int i){return this;} public Builder setContentType(int i){return this;} public AudioAttributes build(){return new AudioAttributes();} } }''',
'android/media/AudioDeviceInfo.java': '''package android.media;
public class AudioDeviceInfo { public static final int TYPE_BLUETOOTH_A2DP=8, TYPE_BLE_HEADSET=26, TYPE_BLE_SPEAKER=27;
private int type; private String name,address;
public AudioDeviceInfo(int t,String n,String a){type=t;name=n;address=a;}
public int getType(){return type;} public CharSequence getProductName(){return name;} public String getAddress(){return address;} }''',
'android/media/AudioManager.java': '''package android.media;
import java.util.*;
public class AudioManager { public static final int GET_DEVICES_OUTPUTS=2;
public AudioDeviceInfo[] connected; public List<AudioDeviceInfo> routed;
public AudioDeviceInfo[] getDevices(int i){return connected;} public List<AudioDeviceInfo> getAudioDevicesForAttributes(AudioAttributes a){return routed;} }''',
'pl/trackgomania/btmax/DevicesTest.java': '''package pl.trackgomania.btmax;
import android.media.*; import java.util.*;
public class DevicesTest {
static int count=0;
static void check(String label, boolean expected, AudioDeviceInfo[] connected, AudioDeviceInfo[] routed, String name, String address){
AudioManager a=new AudioManager();a.connected=connected;a.routed=Arrays.asList(routed);
boolean actual=Devices.eligible(a,name,address); if(actual!=expected)throw new AssertionError(label);count++;
}
public static void main(String[] args){
AudioDeviceInfo bt=new AudioDeviceInfo(8,"Speaker","AA"), other=new AudioDeviceInfo(8,"Other","BB"), duplicate=new AudioDeviceInfo(8,"Speaker","CC"), phone=new AudioDeviceInfo(2,"Phone",""), ble=new AudioDeviceInfo(27,"LE Speaker","DD");
check("selected BT is media route",true,new AudioDeviceInfo[]{bt},new AudioDeviceInfo[]{bt},"speaker","");
check("disconnect",false,new AudioDeviceInfo[]{},new AudioDeviceInfo[]{phone},"Speaker","");
check("connected BT but phone route",false,new AudioDeviceInfo[]{bt},new AudioDeviceInfo[]{phone},"Speaker","");
check("another BT route",false,new AudioDeviceInfo[]{bt,other},new AudioDeviceInfo[]{other},"Speaker","");
check("ambiguous name",false,new AudioDeviceInfo[]{bt,duplicate},new AudioDeviceInfo[]{bt},"Speaker","");
check("address disambiguates",true,new AudioDeviceInfo[]{bt,duplicate},new AudioDeviceInfo[]{bt},"Speaker","AA");
check("renamed device preserves address",true,new AudioDeviceInfo[]{bt},new AudioDeviceInfo[]{bt},"Old Name","AA");
check("empty route fails closed",false,new AudioDeviceInfo[]{bt},new AudioDeviceInfo[]{},"Speaker","");
check("mixed output fails closed",false,new AudioDeviceInfo[]{bt},new AudioDeviceInfo[]{bt,phone},"Speaker","");
check("LE audio",true,new AudioDeviceInfo[]{ble},new AudioDeviceInfo[]{ble},"LE Speaker","");
System.out.println("PASS: "+count+" routing policy scenarios");
} }'''
}
with tempfile.TemporaryDirectory(prefix='btmax-tests-') as tmp:
    tmp=pathlib.Path(tmp)
    for relative, text in sources.items():
        file=tmp/relative
        file.parent.mkdir(parents=True,exist_ok=True)
        file.write_text(text)
    source=tmp/'pl/trackgomania/btmax/Devices.java'
    source.write_text((root/'app/src/main/java/pl/trackgomania/btmax/Devices.java').read_text())
    output=tmp/'classes'
    subprocess.run([javac,'-encoding','UTF-8','-d',str(output)]+[str(p) for p in tmp.rglob('*.java')],check=True)
    subprocess.run([java,'-cp',str(output),'pl.trackgomania.btmax.DevicesTest'],check=True)
