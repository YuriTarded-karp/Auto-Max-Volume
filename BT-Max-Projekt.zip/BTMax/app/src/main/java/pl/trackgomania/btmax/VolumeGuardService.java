package pl.trackgomania.btmax;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.os.*;

public final class VolumeGuardService extends Service {
    static final String STOP = "pl.trackgomania.btmax.STOP";
    static volatile boolean running = false;
    static volatile String status = "Ochrona wyłączona";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;
    private PowerManager.WakeLock wake;
    private String targetName = "", targetAddress = "", notified = "";
    private long lastAttempt = 0, lastWakeRenewal = 0;
    private int restores = 0;
    private final Runnable monitor = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try {
                if (SystemClock.elapsedRealtime() - lastWakeRenewal >= 300_000 || !wake.isHeld()) renewWake();
                check();
            }
            catch (SecurityException e) { update("Brak uprawnień Bluetooth lub do zmiany głośności"); }
            catch (RuntimeException e) { update("Android nie udostępnił wyjścia audio — oczekiwanie"); }
            handler.postDelayed(this, 350);
        }
    };
    @Override public void onCreate() {
        super.onCreate();
        audio = getSystemService(AudioManager.class);
        NotificationChannel channel = new NotificationChannel("guard", "Ochrona głośności Bluetooth", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Stan ochrony i przycisk STOP");
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY;
        }
        SharedPreferences p = getSharedPreferences("guard", MODE_PRIVATE);
        targetName = p.getString("name", "").trim();
        targetAddress = p.getString("address", "");
        if (targetName.isEmpty()) { stopSelf(); return START_NOT_STICKY; }
        startForeground(1, notification("Oczekiwanie na " + targetName), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        running = true;
        if (wake == null) {
            wake = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BTMax:VolumeGuard");
            wake.setReferenceCounted(false);
        }
        renewWake();
        handler.removeCallbacks(monitor);
        handler.post(monitor);
        return START_STICKY;
    }
    private void renewWake() {
        wake.acquire(600_000);
        lastWakeRenewal = SystemClock.elapsedRealtime();
    }
    private void check() {
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            update("Cofnięto uprawnienie Bluetooth. Zatrzymaj ochronę."); return;
        }
        if (audio.isVolumeFixed()) { update("Ten telefon nie pozwala aplikacji zmieniać głośności"); return; }
        if (audio.getMode() != AudioManager.MODE_NORMAL) { update("Przerwa podczas rozmowy lub połączenia audio"); return; }
        if (!Devices.eligible(audio, targetName, targetAddress)) {
            update("Oczekiwanie: " + targetName + " musi być wyjściem multimediów"); return;
        }
        int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int current = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        if (current < max && SystemClock.elapsedRealtime() - lastAttempt >= 1000) {
            // Re-check immediately before modifying the global media stream.
            if (!Devices.eligible(audio, targetName, targetAddress)) return;
            lastAttempt = SystemClock.elapsedRealtime();
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0);
            if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == max) restores++;
        }
        current = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        if (current < max) update("Android ogranicza głośność: " + current + "/" + max);
        else update("Chronione: " + targetName + " • " + current + "/" + max + " • przywrócono: " + restores);
    }
    private Notification notification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, VolumeGuardService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, "guard").setSmallIcon(R.drawable.ic_volume)
                .setContentTitle("BT Max — ochrona głośności").setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(open)
                .setOngoing(true).setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stop).build()).build();
    }
    private void update(String text) {
        status = text;
        if (!text.equals(notified)) {
            notified = text;
            getSystemService(NotificationManager.class).notify(1, notification(text));
        }
    }
    @Override public void onDestroy() {
        running = false;
        status = "Ochrona wyłączona";
        handler.removeCallbacksAndMessages(null);
        if (wake != null && wake.isHeld()) wake.release();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
