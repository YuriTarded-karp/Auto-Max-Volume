package pl.trackgomania.btmax;

import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import java.util.ArrayList;
import java.util.List;

final class Devices {
    static boolean bluetooth(AudioDeviceInfo d) {
        int t = d.getType();
        return t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLE_HEADSET || t == AudioDeviceInfo.TYPE_BLE_SPEAKER;
    }
    static String name(AudioDeviceInfo d) { return d.getProductName().toString().trim(); }
    static List<AudioDeviceInfo> connected(AudioManager audio) {
        List<AudioDeviceInfo> list = new ArrayList<>();
        for (AudioDeviceInfo d : audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) if (bluetooth(d)) list.add(d);
        return list;
    }
    static List<AudioDeviceInfo> routed(AudioManager audio) {
        return audio.getAudioDevicesForAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
    }
    // Fail closed: no name-only selection when several connected outputs share that name.
    static boolean matches(AudioDeviceInfo d, String name, String address) {
        if (!bluetooth(d)) return false;
        if (!address.isEmpty()) return address.equalsIgnoreCase(d.getAddress());
        return name.equalsIgnoreCase(name(d));
    }
    static boolean eligible(AudioManager audio, String name, String address) {
        int matching = 0;
        for (AudioDeviceInfo d : connected(audio)) if (matches(d, name, address)) matching++;
        if (matching != 1) return false;
        List<AudioDeviceInfo> routes = routed(audio);
        // Do not raise the shared media stream when it may also play on a different output.
        if (routes.isEmpty()) return false;
        for (AudioDeviceInfo d : routes) if (!matches(d, name, address)) return false;
        return true;
    }
}
