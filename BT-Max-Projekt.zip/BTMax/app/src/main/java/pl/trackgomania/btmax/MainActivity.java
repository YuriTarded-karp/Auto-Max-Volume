package pl.trackgomania.btmax;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.List;

public final class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private EditText name;
    private TextView state;
    private String address = "";
    private boolean selecting = false;
    private boolean pendingStart = false;
    private Button start;
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            state.setText(VolumeGuardService.status);
            start.setEnabled(!VolumeGuardService.running);
            name.setEnabled(!VolumeGuardService.running);
            handler.postDelayed(this, 500);
        }
    };
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(28), dp(24), dp(24));
        scroll.addView(content);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        setContentView(scroll);
        label(content, "BLUETOOTH · KONTROLA AUDIO", 12, "#6CE5C0", false);
        label(content, "BT Max", 40, "#FFFFFF", true);
        label(content, "Twój głośnik. Zawsze maksimum.", 18, "#B7C1D4", false);
        label(content, "Urządzenie Bluetooth", 16, "#FFFFFF", true);
        name = new EditText(this);
        name.setSingleLine(true);
        name.setTextColor(Color.WHITE);
        name.setHintTextColor(Color.parseColor("#8793A9"));
        name.setHint("Wpisz dokładną nazwę urządzenia");
        name.setText(getSharedPreferences("guard", MODE_PRIVATE).getString("name", ""));
        address = getSharedPreferences("guard", MODE_PRIVATE).getString("address", "");
        name.setTextSize(17);
        name.setPadding(dp(16), dp(16), dp(16), dp(16));
        name.setBackground(background("#202B3B"));
        content.addView(name, new LinearLayout.LayoutParams(-1, -2));
        name.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int f) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { if (!selecting) address = ""; }
            public void afterTextChanged(Editable e) {}
        });
        Button choose = button(content, "Wybierz połączone urządzenie", false);
        choose.setOnClickListener(v -> { if (VolumeGuardService.running) toast("Najpierw zatrzymaj ochronę"); else choose(); });
        state = label(content, "Ochrona wyłączona", 16, "#6CE5C0", true);
        state.setBackground(background("#192A2B"));
        state.setPadding(dp(16), dp(18), dp(16), dp(18));
        start = button(content, "Włącz ochronę · 100%", true);
        start.setOnClickListener(v -> begin());
        button(content, "Zatrzymaj ochronę", false).setOnClickListener(v -> {
            pendingStart = false;
            stopService(new Intent(this, VolumeGuardService.class));
        });
        label(content, "Jak to działa", 18, "#FFFFFF", true);
        label(content, "Po włączeniu aplikacja ustawia maksymalną głośność multimediów. Obniżenie głośności przywróci do maksimum, zwykle w około sekundę. Ochrona działa tylko, gdy wybrane urządzenie jest wyjściem multimediów.", 15, "#B7C1D4", false);
        label(content, "Przyciski na głośniku zadziałają z ochroną, jeśli jego głośność jest synchronizowana z telefonem. Niezależnego pokrętła aplikacja nie odczyta. Ograniczeń głośności Androida nie omija.", 15, "#B7C1D4", false);
        label(content, "Ochrona działa w tle i przy zgaszonym ekranie. STOP jest także w powiadomieniu. Ciągła kontrola zwiększa zużycie baterii. Jeśli telefon zamyka aplikację, ustaw dla BT Max nieograniczone użycie baterii w ustawieniach telefonu.", 15, "#B7C1D4", false);
    }
    private void choose() {
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 10); return;
        }
        try {
            List<AudioDeviceInfo> list = Devices.connected(getSystemService(AudioManager.class));
            if (list.isEmpty()) { toast("Najpierw połącz głośnik lub słuchawki przez Bluetooth"); return; }
            String[] names = new String[list.size()];
            for (int i = 0; i < names.length; i++) names[i] = Devices.name(list.get(i)) + (list.get(i).getAddress().isEmpty() ? "" : "\n" + list.get(i).getAddress());
            new AlertDialog.Builder(this).setTitle("Połączone wyjścia audio").setItems(names, (dialog, i) -> {
                selecting = true;
                name.setText(Devices.name(list.get(i)));
                selecting = false;
                address = list.get(i).getAddress();
            }).setNegativeButton("Anuluj", null).show();
        } catch (RuntimeException e) { toast("Nie można odczytać urządzeń Bluetooth"); }
    }
    private void begin() {
        if (name.getText().toString().trim().isEmpty()) { name.setError("Podaj nazwę urządzenia"); return; }
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            pendingStart = true;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 11); return;
        }
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pendingStart = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 12); return;
        }
        confirmStart();
    }
    private void confirmStart() {
        pendingStart = false;
        if (VolumeGuardService.running) return;
        new AlertDialog.Builder(this).setTitle("Włączyć maksymalną głośność?")
            .setMessage("Głośność multimediów będzie automatycznie wracać do 100%. Aby ją obniżyć, najpierw użyj STOP.")
            .setPositiveButton("Włącz", (d, w) -> {
                String target = name.getText().toString().trim();
                if (target.isEmpty()) { name.setError("Podaj nazwę urządzenia"); return; }
                getSharedPreferences("guard", MODE_PRIVATE).edit().putString("name", target).putString("address", address).apply();
                try { startForegroundService(new Intent(this, VolumeGuardService.class)); }
                catch (RuntimeException e) { toast("Android nie pozwolił uruchomić ochrony. Spróbuj ponownie."); }
            }).setNegativeButton("Anuluj", null).show();
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (code == 10) { if (granted) choose(); else toast("Wymagana jest zgoda na urządzenia w pobliżu"); }
        if (code == 11) { if (granted && pendingStart) begin(); else { pendingStart = false; toast("Wymagana jest zgoda na urządzenia w pobliżu"); } }
        if (code == 12 && pendingStart) confirmStart();
    }
    private TextView label(LinearLayout parent, String text, int size, String color, boolean bold) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(Color.parseColor(color));
        v.setLineSpacing(dp(3), 1); if (bold) v.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(18);
        parent.addView(v, p); return v;
    }
    private GradientDrawable background(String color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(Color.parseColor(color)); d.setCornerRadius(dp(14)); return d;
    }
    private Button button(LinearLayout parent, String text, boolean primary) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(16);
        b.setTextColor(Color.parseColor(primary ? "#10151E" : "#E5ECF7"));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor(primary ? "#6CE5C0" : "#283548")));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(56)); p.topMargin = dp(8); p.bottomMargin = dp(12);
        parent.addView(b, p); return b;
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    @Override public void onResume() { super.onResume(); handler.post(refresh); }
    @Override public void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
}
